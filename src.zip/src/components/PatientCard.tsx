import Image from 'next/image';
import Link from 'next/link';
import { PatientWithStringId } from '@/types';
import { PlusIcon } from '@heroicons/react/24/solid';
import { BeakerIcon, ClipboardDocumentListIcon } from '@heroicons/react/24/outline';

interface PatientCardProps {
  patient: PatientWithStringId;
}

export default function PatientCard({ patient }: PatientCardProps) {
  return (
    <Link href={`/patients/${patient._id}`} className="block">
      <div className="relative bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg rounded-md overflow-hidden max-w-md hover:shadow-xl transition-all duration-300 ease-in-out">
        
        {/* Avatar Section with Gradient Overlay */}
        <div className="relative">
          <Image
            className="object-cover w-full h-40"
            src={patient.avatarUrl || '/avatars/patient-avatar.png'}
            alt={patient.name}
            width={400}
            height={160}
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50 flex items-end p-4">
            <div>
              <h3 className="text-xl font-semibold text-white">
                {patient.name}
              </h3>
              <p className="text-sm text-gray-300">{patient.address.city}, {patient.address.province}</p>
            </div>
          </div>
        </div>

        {/* Patient Information Section */}
        <div className="bg-white p-6 flex justify-between items-center">
          <div>

            <div className="mt-1 flex gap-6">
            <Link
              href={`/patients/${patient._id}/tests`}
              className="flex items-center gap-2 text-sm text-teal-400  transition-colors cursor-pointer"
            >
              <BeakerIcon className="h-5 w-5" aria-hidden="true" />
              <span>{patient.testsCount} Tests</span>
            </Link>
            <Link
              href={`/patients/${patient._id}/requisitions`}
              className="flex items-center gap-2 text-sm text-yellow-400  transition-colors cursor-pointer"
            >
              <ClipboardDocumentListIcon className="h-5 w-5" aria-hidden="true" />
              <span>{patient.requisitionsCount} Requisitions</span>
            </Link>
          </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

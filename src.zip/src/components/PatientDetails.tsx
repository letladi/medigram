import Image from 'next/image'
import { PatientWithStringId } from '@/types'

interface PatientDetailsProps {
  patient: PatientWithStringId
}

export default function PatientDetails({ patient }: PatientDetailsProps) {
  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden">
      <div className="p-6">
        <div className="flex items-center space-x-6">
          <Image
            src={patient.avatarUrl || '/default-avatar.png'}
            alt={patient.name}
            width={100}
            height={100}
            className="rounded-full"
          />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{patient.name}</h2>
            <p className="text-gray-600">{patient.gender}, {new Date(patient.dateOfBirth).toLocaleDateString()}</p>
            <p className="text-gray-600">{patient.contactNumber}</p>
            <p className="text-gray-600">{patient.email}</p>
          </div>
        </div>
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Address</h3>
          <p className="text-gray-600">{patient.address.street}</p>
          <p className="text-gray-600">{patient.address.city}, {patient.address.province}</p>
          <p className="text-gray-600">{patient.address.postalCode}</p>
        </div>
      </div>
    </div>
  )
}
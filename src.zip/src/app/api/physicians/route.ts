import { NextRequest, NextResponse } from 'next/server';
import clientPromise from '@/lib/mongodb';
import { Physician } from '@/types';

export async function GET() {
  try {
    const client = await clientPromise;
    const db = client.db("medigram");
    const physicians = await db.collection<Physician>("physicians").find({}).toArray();
    return NextResponse.json(physicians);
  } catch (error) {
    console.error('Error fetching physicians:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const client = await clientPromise;
    const db = client.db("medigram");
    const physicianData = await request.json();

    const newPhysician: Physician = {
      ...physicianData,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const result = await db.collection<Physician>("physicians").insertOne(newPhysician);
    return NextResponse.json({ id: result.insertedId }, { status: 201 });
  } catch (error) {
    console.error('Error adding physician:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
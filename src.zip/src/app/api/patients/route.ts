import { NextRequest, NextResponse } from 'next/server';
import clientPromise from '@/lib/mongodb';
import { Patient } from '@/types';
import { ObjectId } from 'mongodb';
import { upload } from '@/lib/api-config';
import path from 'path';
import fs from 'fs/promises';

export async function GET(request: NextRequest) {
  const client = await clientPromise;
  const db = client.db("medigram");
  const patients = await db.collection<Patient>("patients").find({}).toArray();
  return NextResponse.json(patients);
}

export async function POST(request: NextRequest) {
  await new Promise((resolve, reject) => {
    upload.single('avatar')(request as any, {} as any, (err: any) => {
      if (err) reject(err);
      else resolve(true);
    });
  });

  const formData = await request.formData();
  const client = await clientPromise;
  const db = client.db("medigram");

  const patientData: Patient = {
    name: formData.get('name') as string,
    address: JSON.parse(formData.get('address') as string),
    dateOfBirth: new Date(formData.get('dateOfBirth') as string),
    gender: formData.get('gender') as 'Male' | 'Female' | 'Other',
    contactNumber: formData.get('contactNumber') as string,
    email: formData.get('email') as string,
    avatarUrl: (request as any).file ? `/uploads/${(request as any).file.filename}` : undefined,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const result = await db.collection<Patient>("patients").insertOne(patientData);
  return NextResponse.json({ id: result.insertedId }, { status: 201 });
}

export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: 'Patient ID is required' }, { status: 400 });
  }

  const client = await clientPromise;
  const db = client.db("medigram");

  const patient = await db.collection<Patient>("patients").findOne({ _id: new ObjectId(id) });

  if (!patient) {
    return NextResponse.json({ error: 'Patient not found' }, { status: 404 });
  }

  if (patient.avatarUrl) {
    const filePath = path.join(process.cwd(), 'public', patient.avatarUrl);
    await fs.unlink(filePath).catch(console.error);
  }

  await db.collection<Patient>("patients").deleteOne({ _id: new ObjectId(id) });

  return NextResponse.json({ message: 'Patient deleted successfully' });
}
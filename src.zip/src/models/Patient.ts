import { ObjectId } from 'mongodb';

export interface Patient {
  _id?: ObjectId;
  name: string;
  address: string;
  avatarUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}